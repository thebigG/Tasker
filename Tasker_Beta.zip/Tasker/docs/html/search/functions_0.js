var searchData=
[
  ['calculateproductivepercentage_54',['calculateProductivePercentage',['../classutil_1_1StatsUtility.html#a1556c3650019332538bb4d41dc5856df',1,'util::StatsUtility']]],
  ['calculateunproductivepercentage_55',['calculateUnproductivePercentage',['../classutil_1_1StatsUtility.html#a1c69e04f902bc84787c420b2dee3c4a4',1,'util::StatsUtility']]],
  ['createseries_56',['createSeries',['../classTempChartQWidget.html#a1c7a54a640aef43326613fdc28b4c615',1,'TempChartQWidget']]]
];
