var searchData=
[
  ['updatelegendlayout_37',['updateLegendLayout',['../classTempChartQWidget.html#a5ec09eb9b5018bd0570e6bea2012524e',1,'TempChartQWidget']]],
  ['user_38',['User',['../classudata_1_1User.html',1,'udata']]]
];
