var indexSectionsWithContent =
{
  0: "cgiklrstu~",
  1: "ciklstu",
  2: "cglrstu~",
  3: "l"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions",
  3: "enums"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions",
  3: "Enumerations"
};

