var searchData=
[
  ['updatelegendlayout_79',['updateLegendLayout',['../classTempChartQWidget.html#a5ec09eb9b5018bd0570e6bea2012524e',1,'TempChartQWidget']]]
];
