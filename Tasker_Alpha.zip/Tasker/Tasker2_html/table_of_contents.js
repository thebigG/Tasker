var ToC = `
<div id="main-dropdown" class="dropdown" tabindex="0">
<button id="dropdown-button" class="dropbtn"><span>Contents </span><img id="dropdown-icon" src="ToCdropdown.png" style="height:12px"></button>
<div id="dropdown-buffer" class="dropdown-border" style="height:120px;width:300px;"></div><div id="nav-dropdown-content" class="dropdown-content"><a href="projectoverview.html">Overview</a>
<a href="dictionary_&.html">Data Dictionary</a>
<a href="contents_file_A.html">File Contents</a>
<a href="progunit_xref_C.html">Program Unit Cross Reference</a>
<a href="object_xref_&.html">Object Cross Reference</a>
<a href="type_xref_C.html">Type Cross Reference</a>
<a href="macro_xref_A.html">Macro Cross Reference</a>
<a href="inc_xref_A.html">Include File Cross Reference</a>
<a href="simpleinvtree_C.html">Simple Invocation Tree</a>
<a href="progunitcomp_metrics_C.html">Program Unit Complexity</a>
<a href="projmetrics.html">Project Metrics</a>
<a href="progunit_metrics_C.html">Program Unit Metrics</a>
<a href="file_metrics_A.html">File Metrics</a>
<a href="fileam_A.html">File Average Metrics</a>
<a href="classm_C.html">Class Metrics</a>
<a href="classoom_C.html">Class OO Metrics</a>
<a href="uninitializeditems_A.html">Uninitialized Items</a>
<a href="unuseditemsall_A.html">Unused Objects and Functions</a>
<a href="unusedobj_A.html">Unused Objects</a>
<a href="unusedprogunit_A.html">Unused Program Units</a>
<a href="entity_index.html">Index</a>
<a href="entity_tree_index.html">Tree Index</a>

</div>
</div>
`